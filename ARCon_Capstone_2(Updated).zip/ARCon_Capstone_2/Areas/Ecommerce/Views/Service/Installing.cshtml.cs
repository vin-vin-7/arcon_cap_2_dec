using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ARCon_Capstone_2.Views.Home.Services
{
    public class InstallingModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
