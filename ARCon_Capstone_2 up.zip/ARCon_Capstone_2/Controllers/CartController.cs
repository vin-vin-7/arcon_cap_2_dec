﻿using Microsoft.AspNetCore.Mvc;

public class CartController : Controller
{
    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Checkout()
    {
        return View();
    }
}
