﻿namespace ARCon_Capstone_2.DTOs
{
    public class SupplierUpdateDto
    {
        public string Supplier_Name { get; set; }
        public string Proprietor_Name { get; set; }
        public string Proprietor_Contact_No { get; set; }
        public string DTI_Business_Number { get; set; }
        public string Tin_Number { get; set; }
        public string? Official_Website { get; set; }
        public string Landline_No { get; set; }
        public string? Supplier_Rep { get; set; }
        public string Rep_Email { get; set; }
        public string Rep_Contact_No { get; set; }
        public string House_Unit { get; set; }
        public string Street_Name { get; set; }
        public string Barangay { get; set; }
        public string City { get; set; }
        public string Province { get; set; }
        public string Landmark { get; set; }
        public string Note { get; set; }
    }
}
