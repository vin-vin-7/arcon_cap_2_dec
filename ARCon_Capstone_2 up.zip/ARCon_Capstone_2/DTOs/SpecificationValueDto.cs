﻿namespace ARCon_Capstone_2.DTOs
{
    public class SpecificationValueDto
    {
        public string KeyName { get; set; }
    }

}