using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ARCon_Capstone_2.Views.Product
{
    public class FeaturedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
