using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ARCon_Capstone_2.Views.Home.Services
{
    public class RepairModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
