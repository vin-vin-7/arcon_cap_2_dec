﻿namespace ARCon_Capstone_2.DTOs
{
    public class SpecUpdateDto
    {
        public int SpecId { get; set; }
        public string Value { get; set; }
    }
}
