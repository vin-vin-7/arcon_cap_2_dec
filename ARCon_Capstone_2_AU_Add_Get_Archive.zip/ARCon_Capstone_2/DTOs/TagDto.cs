﻿namespace ARCon_Capstone_2.DTOs
{
    public class TagDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }   
}
