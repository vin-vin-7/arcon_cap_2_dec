﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ARCon_Capstone_2.Models;

public partial class role
{
    [Key]
    public int id { get; set; }

    [StringLength(20)]
    public string role_name { get; set; } = null!;

    public string? role_description { get; set; }

    [ForeignKey("role_id")]
    [InverseProperty("roles")]
    public virtual ICollection<admin_user> users { get; set; } = new List<admin_user>();
}
