﻿namespace ARCon_Capstone_2.DTOs
{
    public class ProductSpecificationDto
    {
        public int KeyId { get; set; }
        public string Value { get; set; }
    
}
}
