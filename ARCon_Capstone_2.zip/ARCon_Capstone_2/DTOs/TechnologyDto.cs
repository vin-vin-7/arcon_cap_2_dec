﻿namespace ARCon_Capstone_2.DTOs
{
    public class TechnologyDto
    {
        public string TechnologyName { get; set; }
        public string? TechnologyDesc { get; set; }
    }
}
