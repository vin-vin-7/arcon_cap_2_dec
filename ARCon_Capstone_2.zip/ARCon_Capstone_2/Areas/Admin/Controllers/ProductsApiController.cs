﻿using ARCon_Capstone_2.Data;
using ARCon_Capstone_2.DTOs;
using ARCon_Capstone_2.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[AllowAnonymous]
[Area("Admin")]
[ApiController]
[Route("admin/api/products")]
public class ProductsApiController : ControllerBase
{
    private readonly ARCon_Capstone_2_DbContext _context;

    public ProductsApiController(ARCon_Capstone_2_DbContext context)
    {
        _context = context;
    }

    [HttpPost("add")]
    public async Task<IActionResult> Add([FromBody] AddProductsDto dto)
    {
        using var tx = await _context.Database.BeginTransactionAsync();

        try
        {
            // 1️⃣ COMPUTE ACTUAL SELLING PRICE (SERVER-SIDE ONLY)
            decimal actualSellingPrice;


            // normalize hard (best practice)
            var discountType = (dto.DiscountType ?? "NONE").Trim().ToUpper();

            switch (discountType)
            {
                case "NONE":
                    actualSellingPrice = dto.OriginalSellingPrice;
                    break;

                case "PERCENTAGE":
                    if (dto.DiscountValue <= 0 || dto.DiscountValue > 100)
                        return BadRequest("Invalid discount percentage.");

                    actualSellingPrice =
                        dto.OriginalSellingPrice -
                        (dto.OriginalSellingPrice * dto.DiscountValue / 100m);
                    break;

                case "AMOUNT":
                    if (dto.DiscountValue <= 0)
                        return BadRequest("Invalid discount amount.");

                    if (dto.DiscountValue >= dto.OriginalSellingPrice)
                        return BadRequest("Discount amount cannot exceed original price.");

                    actualSellingPrice =
                        dto.OriginalSellingPrice - dto.DiscountValue;
                    break;

                default:
                    return BadRequest($"Invalid discount type: '{dto.DiscountType}'");
            }

            //Any external link MUST include the protocol
            if (!string.IsNullOrWhiteSpace(dto.ArUrl) &&
    !           dto.ArUrl.StartsWith("http://") &&
    !           dto.ArUrl.StartsWith("https://"))
            {
                dto.ArUrl = "https://" + dto.ArUrl;
            }


            // 2️⃣ CREATE PRODUCT (NO SAVE YET)
            var product = new product
            {
                manufacturer_id = dto.ManufacturerId,
                form_factor_id = dto.FormFactorID,
                product_model = dto.ProductModel.ToUpper(),
                product_series = dto.ProductSeries.ToUpper(),
                sku = dto.Sku,
                part_number_a = dto.PartNumberA.ToUpper(),
                part_number_b = dto.PartNumberB.ToUpper(),
                original_selling_price = dto.OriginalSellingPrice,
                discount_type = discountType,
                discount_value = dto.DiscountValue,
                actual_selling_price = actualSellingPrice,
                ar_url = dto.ArUrl,
                manufacturer_warranty_years = dto.ManufacturerWarrantyYears,
                outright_replacement_days = dto.OutrightReplacementDays,
                gross_weight_a = dto.GrossWeightA,
                gross_weight_b = dto.GrossWeightB,
                total_gross_weight = dto.TotalGrossWeight,

                status = "ACTIVE",
                created_at = DateTime.UtcNow
            };

            _context.products.Add(product);
            await _context.SaveChangesAsync(); // ✅ product.id available here

            // 3️⃣ TECHNOLOGIES
            foreach (var t in dto.Technologies)
            {
                var tech = await _context.technology_types
                    .FirstOrDefaultAsync(x => x.technology_name == t.TechnologyName);

                if (tech == null)
                {
                    tech = new technology_type
                    {
                        technology_name = t.TechnologyName.ToUpper(),
                        technology_desc = t.TechnologyDesc
                    };
                    _context.technology_types.Add(tech);
                    await _context.SaveChangesAsync();
                }

                _context.product_technologies.Add(new product_technology
                {
                    product_id = product.id,
                    technology_id = tech.id
                });
            }

            // 4️⃣ SPECIFICATIONS
            foreach (var s in dto.Specifications)
            {
                // optional safety check
                var keyExists = await _context.specification_keys
                    .AnyAsync(k => k.id == s.KeyId);

                if (!keyExists)
                    return BadRequest("Invalid specification key.");

                _context.technical_specifications.Add(new technical_specification
                {
                    product_id = product.id,
                    key_id = s.KeyId,
                    value = s.Value
                });
            }


            // 5️⃣ TAGS
            foreach (var name in dto.Tags)
            {
                var tag = await _context.tags
                    .FirstOrDefaultAsync(x => x.tag_name == name);

                if (tag == null)
                {
                    tag = new tag { tag_name = name };
                    _context.tags.Add(tag);
                    await _context.SaveChangesAsync();
                }

                _context.product_tags.Add(new product_tag
                {
                    product_id = product.id,
                    tag_id = tag.id
                });
            }

            await _context.SaveChangesAsync();
            await tx.CommitAsync();

            return Ok(new { product.id });
        }
        catch (Exception ex)
        {
            await tx.RollbackAsync();
            return BadRequest(ex.ToString());
        }
    }

    [HttpGet]
    public async Task<IActionResult> GetAll(int page = 1,
    int pageSize = 3, string sortBy = "date", string sortDir = "desc")
    {
        var query = _context.products
            .Where(p => p.status.ToUpper() != "ARCHIVED")
            .Include(p => p.manufacturer)
            .Include(p => p.form_factor)
            .AsQueryable();

        bool asc = sortDir.ToLower() == "asc";

        query = sortBy switch
        {
            "sku" => asc
                ? query.OrderBy(p => p.sku)
                : query.OrderByDescending(p => p.sku),
            "manufacturer" => asc
                ? query.OrderBy(p => p.manufacturer.manufacturer_name)
                : query.OrderByDescending(p => p.manufacturer.manufacturer_name),
            "productModel" => asc
                ? query.OrderBy(p => p.product_model)
                : query.OrderByDescending(p => p.product_model),
            "productSeries" => asc
               ? query.OrderBy(p => p.product_series)
               : query.OrderByDescending(p => p.product_series),
            "formfactor" => asc
                ? query.OrderBy(p => p.form_factor.form_factor1)
                : query.OrderByDescending(p => p.form_factor.form_factor1),
            "originalSellingPrice" => asc
                ? query.OrderBy(p => p.original_selling_price)
                : query.OrderByDescending(p => p.original_selling_price),
            "actualPrice" => asc
                ? query.OrderBy(p => p.actual_selling_price)
                : query.OrderByDescending(p => p.actual_selling_price),
            "status" => asc
                ? query.OrderBy(p => p.status)
                : query.OrderByDescending(p => p.status),
            "discountType" => asc
                ? query.OrderBy(p => p.discount_type)
                : query.OrderByDescending(p => p.discount_type),
            "discountValue" => asc
                ? query.OrderBy(p => p.discount_value)
                : query.OrderByDescending(p => p.discount_value),
            "createDate" => asc
                ? query.OrderBy(p => p.created_at)  
                : query.OrderByDescending(p => p.created_at),
            _ => asc
                ? query.OrderBy(p => p.created_at)
                : query.OrderByDescending(p => p.created_at),
               
        };

        var totalCount = await query.CountAsync();
        var items = await query
        .Skip((page - 1) * pageSize)
        .Take(pageSize)
        .Select(p => new
        {   
            p.id,
            p.sku,
            manufacturer = p.manufacturer.manufacturer_name,
            p.product_model,
            p.product_series,
            formfactor = p.form_factor.form_factor1,
            p.original_selling_price,
            p.actual_selling_price,
            p.status,
            p.discount_type,
            p.ar_url,
            p.discount_value,
            p.created_at,
        })
        
        .ToListAsync();

        return Ok(new {
            items,
            totalCount
    });   
    }
    
    [HttpDelete("{id}")]
        public async Task<IActionResult> Archive(int id)
        {
            var product = await _context.products.FindAsync(id);
            if (product == null)
                return NotFound();

            product.status = "ARCHIVED";
            product.updated_at = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            return Ok(new { id = product.id, status = product.status });
        }

    [HttpGet("summary/{id}")]
    public async Task<IActionResult> GetProductSummary(int id)
    {

        var product = await _context.products      
            .Include(p => p.form_factor)
            .Include(p => p.manufacturer)

            .FirstOrDefaultAsync(p => p.id == id);

        if (product == null)
               return NotFound();

        // -- spec (key-value pairs)
        var specifications = await _context.technical_specifications
            .Where(ts => ts.product_id == id)
            .Join(
            _context.specification_keys,
            ts => ts.key_id,
            sk => sk.id,
            (ts, sk) => new
            {
                key = sk.keyname,
                value = ts.value,
            }
        )
            .OrderBy(x => x.key)
            .ToListAsync();

        var tags = await _context.product_tags
            .Where (pt => pt.product_id == id)
            .Join(
                _context.tags,
                pt => pt.tag_id,
                t => t.id,
                (pt, t) => t.tag_name
            )
            .OrderBy(t => t)
            .ToListAsync();

        var technologies = await _context.product_technologies
            .Where(pt => pt.product_id == id)
            .Join(
                _context.technology_types,
                pt => pt.technology_id,
                tt => tt.id,
                (pt, tt) => new
                { 
                    id = tt.id,
                    name = tt.technology_name,
                    description = tt.technology_desc
                }
            )
            .OrderBy (t => t.name)
            .ToListAsync();
        var result = new
        {
            //basic info
            sku = product.sku,
            product_Model = product.product_model,
            product_Series = product.product_series,
            part_Number_A = product.part_number_a,
            part_Number_B = product.part_number_b,
            form_factor = product.form_factor.form_factor1,
            manufacturer = product.manufacturer.manufacturer_name,
            status = product.status,
            original_Selling_Price = product.original_selling_price,
            discounted_Selling_Price = product.discounted_selling_price,
            discount_Type = product.discount_type,
            discount_Amount = product.discount_type,
            discount_Value = product.discount_value,
            actual_Selling_Price = product.actual_selling_price,
            ar_url = product.ar_url,
            created_At = product.created_at,
            updated_At = product.updated_at,
            manufacturer_Warranty_Years = product.manufacturer_warranty_years,
            outright_Replacement_Days = product.outright_replacement_days,
            gross_Weight_A = product.gross_weight_a,
            gross_Weight_B = product.gross_weight_b,
            total_Gross_Weight = product.total_gross_weight,
            //details query from multiple tables (Joined)
            specifications = specifications,
            tags = tags,
            technologies = technologies 
        };
        return Ok(result);
    }

    //update products
    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateProduct(int id, [FromBody] ProductUpdateDto dto)
    { 
    
    
    }

}
