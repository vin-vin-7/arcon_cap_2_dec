﻿using ARCon_Capstone_2.Data;
using ARCon_Capstone_2.DTOs;
using ARCon_Capstone_2.Models;
using ARCon_Capstone_2.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ARCon_Capstone_2.Services;

[AllowAnonymous]
[ApiController]
[Route("api/adminusers")]


public class AdminUsersApiController : ControllerBase
{
    private readonly ARCon_Capstone_2_DbContext _context;
    private readonly IEmailServices _emailService;
    public AdminUsersApiController(
       ARCon_Capstone_2_DbContext context,
       IEmailServices emailService)
    {
        _context = context;
        _emailService = emailService;
    }

    [HttpPost("create")]
    public async Task<IActionResult> Create([FromBody]CreateAdminUserDto dto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        // ❌ username already exists
        if (await _context.admin_users
            .AnyAsync(u => u.user_name == dto.UserName))
        {
            return BadRequest("Username already exists.");
        }

        // ❌ email already exists
        if (await _context.admin_users
            .AnyAsync(u => u.email_address == dto.EmailAddress))
        {
            return BadRequest("Email address already exists.");
        }
        // ❌ contact number already exists
        if (await _context.admin_users
            .AnyAsync(u => u.contact_no == dto.ContactNo))
        {
            return BadRequest("Contact number already exists.");
        }

        var tempPassword = PasswordHelper.GenerateTemporaryPassword();
        var hash = BCrypt.Net.BCrypt.HashPassword(tempPassword);


        foreach (var s in dto.Schedule)
        {
            if (!s.IsRestday && (!s.LoginTime.HasValue || !s.LogoutTime.HasValue))
                return BadRequest($"Login and Logout required for {s.DayOfWeek}");

            if (!s.IsRestday && s.LoginTime >= s.LogoutTime)
                return BadRequest($"Login time must be earlier than Logout time for {s.DayOfWeek}");
        }

        var user = new admin_user
        {
            user_name = dto.UserName,
            first_name = dto.FirstName,
            last_name = dto.LastName,
            email_address = dto.EmailAddress,
            contact_no = dto.ContactNo,
            home_address = dto.HomeAddress,
            birthday =  dto.Birthday,
            status = "ACTIVE",
            password_hash = hash,
            created_at = DateTime.UtcNow,
        };

        _context.admin_users.Add(user);
        await _context.SaveChangesAsync();

        _context.user_roles.Add(new user_role
        {
            user_id = user.id,
            role_id = dto.RoleId
        });

        foreach (var s in dto.Schedule)
        {
            _context.work_schedules.Add(new work_schedule
            {
                employee_id = user.id,
                day_of_week = s.DayOfWeek,
                login_time = s.IsRestday ? null : s.LoginTime,
                logout_time = s.IsRestday ? null : s.LogoutTime,
                is_restday = s.IsRestday,
                created_at = DateTime.UtcNow,
            });
        }



        await _context.SaveChangesAsync();

        // TEMPORARY: email later
        //await _emailService.SendAsync(
        //    user.email_address,
        //    "Your Account Is Ready",
        //    $"Username: {user.user_name}\nPassword: {tempPassword}"
        //);

        return Ok();
    }


}