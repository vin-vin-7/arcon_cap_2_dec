﻿function openCreateUserModal() {
    hideCreateUserError();
    clearCreateUserFieldErrors();
    buildScheduleTable();

    new bootstrap.Modal(
        document.getElementById("createUserModal")
    ).show();
}




function buildScheduleTable()
{
    const days = [
        "Monday", "Tuesday", "Wednesday",
        "Thursday", "Friday", "Saturday", "Sunday"
    ];

    const tbody = document.getElementById("scheduleBody");
    tbody.innerHTML = "";

    days.forEach(d => {
        tbody.insertAdjacentHTML("beforeend", `
            <tr>
                <td class="fw-semibold">${d}</td>
                <td>
                    <input type="time"
                           class="form-control sched-login">
                </td>
                <td>
                    <input type="time"
                           class="form-control sched-logout">
                </td>
                <td class="text-center">
                    <input type="checkbox"
                           class="form-check-input sched-rest"
                           onchange="toggleRestDay(this)">
                </td>
            </tr>
        `);
    });
}

function toggleRestDay(cb) {
    const row = cb.closest("tr");
    row.querySelector(".sched-login").disabled = cb.checked;
    row.querySelector(".sched-logout").disabled = cb.checked;

    if (cb.checked) {
        row.querySelector(".sched-login").value = null;
        row.querySelector(".sched-logout").value = null;
    }
}

 function openCreateUserModal() {
    buildScheduleTable();

    new bootstrap.Modal(
        document.getElementById("createUserModal")
    ).show();
};

function buildScheduleTable()
{
    const days = [
        "Monday", "Tuesday", "Wednesday",
        "Thursday", "Friday", "Saturday", "Sunday"
    ];

    const tbody = document.getElementById("scheduleBody");
    tbody.innerHTML = "";

    days.forEach(d => {
        tbody.insertAdjacentHTML("beforeend", `
            <tr>
                <td class="fw-semibold">${d}</td>
                <td>
                    <input type="time"
                           class="form-control sched-login">
                </td>
                <td>
                    <input type="time"
                           class="form-control sched-logout">
                </td>
                <td class="text-center">
                    <input type="checkbox"
                           class="form-check-input sched-rest"
                           onchange="toggleRestDay(this)">
                </td>
            </tr>
        `);
    });
}

function toggleRestDay(cb) {
    const row = cb.closest("tr");
    row.querySelector(".sched-login").disabled = cb.checked;
    row.querySelector(".sched-logout").disabled = cb.checked;

    if (cb.checked) {
        row.querySelector(".sched-login").value = null;
        row.querySelector(".sched-logout").value = null;
    }
}

function createUser() {

    const userName = document.getElementById("cuUserName").value.trim();
    const firstName = document.getElementById("cuFirstName").value.trim();
    const lastName = document.getElementById("cuLastName").value.trim();
    const email = document.getElementById("cuEmail").value.trim();
    const contactNo = document.getElementById("cuContactNo").value.trim();
    const birthDay = document.getElementById("cuBirthday").value.trim();
    const homeAddress = document.getElementById("cuHomeAddress").value.trim();
    const roleId = document.getElementById("cuRole").value;

    if (!userName || !email || !roleId) {
        alert("Username, Email, and Role are required.");
        return;
    }

    const schedule = [];

    document.querySelectorAll("#scheduleBody tr").forEach(r => {
        const isRest = r.querySelector(".sched-rest").checked;

        const loginVal = r.querySelector(".sched-login").value;
        const logoutVal = r.querySelector(".sched-logout").value;

        schedule.push({
            dayOfWeek: r.children[0].innerText,
            loginTime: isRest || !loginVal ? null : loginVal + ":00",
            logoutTime: isRest || !logoutVal ? null : logoutVal + ":00",
            isRestday: isRest
        });
    });


    const payload = {
        userName,
        firstName,
        lastName,
        emailAddress: email,
        contactNo,
        birthday: birthDay !== "" ? birthDay : null,
        //status = "ACTIVE",
        homeAddress,
        roleId: parseInt(roleId),
        schedule
    };

    fetch("/api/adminusers/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
    })
        .then(async r => {
            if (!r.ok) {
                const msg = await r.text();
                throw new Error(msg);
            }

            // success
            hideCreateUserError();
            alert("User created successfully.");
            location.reload();
        })
        .catch(err => {
            showCreateUserError(err.message);
            highlightCreateUserField(err.message);
        });

}

function showCreateUserError(message) {
    const box = document.getElementById("createUserError");
    box.textContent = message;
    box.classList.remove("d-none");
}

function hideCreateUserError() {
    const box = document.getElementById("createUserError");
    box.classList.add("d-none");
    box.textContent = "";
}

function clearCreateUserFieldErrors() {
    document
        .querySelectorAll("#createUserModal .is-invalid")
        .forEach(e => e.classList.remove("is-invalid"));
}

function highlightCreateUserField(message) {
    clearCreateUserFieldErrors();

    const msg = message.toLowerCase();

    if (msg.includes("username")) {
        document.getElementById("cuUserName")?.classList.add("is-invalid");
    }

    if (msg.includes("email")) {
        document.getElementById("cuEmail")?.classList.add("is-invalid");
    }

    if (msg.includes("contact")) {
        document.getElementById("cuContactNo")?.classList.add("is-invalid");
    }
}

